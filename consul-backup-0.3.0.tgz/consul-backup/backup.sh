#!/bin/sh
set -e

export TIMESTAMP=$(date +%Y-%m-%d-%H-%M-%S)
export TMP_DIR="/backup/${BACKUP_ID}"
export SNAPSHOT_NAME="${TMP_DIR}/${BACKUP_ID}-snapshot-${TIMESTAMP}"
export CONSUL_BIN="/bin/consul"
export BACKUP_DIR="/backup-target/${BACKUP_ID}"

if [ ! -d $TMP_DIR ]; then
  mkdir $TMP_DIR
fi
if [ ! -d $BACKUP_DIR ]; then
  mkdir $BACKUP_DIR
fi

# dump consul database
echo "Exporting consul database..."
${CONSUL_BIN} snapshot save ${SNAPSHOT_NAME} ||  { echo "Error: Failed to create snapshot"; exit 1; }
test -e ${SNAPSHOT_NAME} ||  { echo "Error: ${SNAPSHOT_NAME} does not exist "; exit 1; }
gzip "${SNAPSHOT_NAME}"
export SNAPSHOT_NAME=$SNAPSHOT_NAME.gz
if [ $ENCRYPTION_ENABLED = "true" ];then
  echo "Encrypting backups..."
  openssl aes-256-cbc -v -a -salt -in "${SNAPSHOT_NAME}.gz"  -out "${SNAPSHOT_NAME}.enc" -pbkdf2 -kfile /etc/encrypt-key/password
  export SNAPSHOT_NAME=$SNAPSHOT_NAME.enc
fi

echo "Copying backups to the target..."
chown -R 1001 "$SNAPSHOT_NAME"
cp "${SNAPSHOT_NAME}" ${BACKUP_DIR}
rm ${SNAPSHOT_NAME}
# rotate old backups
echo "Rotating backups..."
export OLD_BACKUPS="$(find ${BACKUP_DIR}/* -mtime "+$RETENTION")"
export RECENT_BACKUP_COUNT="$(find ${BACKUP_DIR}/* -mtime "-$RETENTION" | wc -l)"

if [ "$OLD_BACKUPS" ] && [ "$RECENT_BACKUP_COUNT" -ge "$RETENTION" ];
  then echo "Deleting backups older than "$RETENTION" days:";
  echo "$OLD_BACKUPS";
  rm -v $OLD_BACKUPS;
fi

export CURRENT_BACKUPS="$(find ${BACKUP_DIR}/*)"

if [ "$CURRENT_BACKUPS" ]; then echo "Current backups:"; echo "$CURRENT_BACKUPS"; fi
