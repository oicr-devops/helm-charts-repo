#!/bin/sh
set -e
# etcd credentials
. /etc/etcd.env
export TIMESTAMP=$(date +%Y-%m-%d-%H-%M-%S)

if [ "$TMP_DIR" = "true" ]; then
    BACKUP_DIR="/backup/${BACKUP_ID}"
else
    BACKUP_DIR="/backup-target/${BACKUP_ID}"
fi

export SNAPSHOT_NAME="${BACKUP_DIR}/${BACKUP_ID}-${TIMESTAMP}"

if [ ! -d $BACKUP_DIR ]; then
  mkdir $BACKUP_DIR
fi

# dump etcd database
echo "Exporting etcd database..."
etcdctl --cacert="$ETCD_PEER_TRUSTED_CA_FILE" --cert="$ETCD_CERT_FILE" --key="$ETCD_KEY_FILE" snapshot save "${SNAPSHOT_NAME}"
echo "Exit code: $?"
test -e "${SNAPSHOT_NAME}"
echo "Created archive: ${SNAPSHOT_NAME}"
echo "Compressing..."
gzip "${SNAPSHOT_NAME}"
export SNAPSHOT_NAME=$SNAPSHOT_NAME.gz

if [ $ENCRYPTION_ENABLED = "true" ];then
  echo "Encrypting...."
  openssl aes-256-cbc -v -a -salt -in "$SNAPSHOT_NAME"  -out "${SNAPSHOT_NAME}.enc" -pbkdf2 -kfile /etc/backup-key/password
  echo "Exit code: $?"
  echo "Removing $SNAPSHOT_NAME"
  rm $SNAPSHOT_NAME
  export SNAPSHOT_NAME=$SNAPSHOT_NAME.enc
  echo "Encrypted backup: ${SNAPSHOT_NAME}"
fi

if [ "$TMP_DIR" = "true" ]; then
    echo "Moving $SNAPSHOT_NAME to the target..."
    BACKUP_DIR="/backup-target/${BACKUP_ID}"
    mv "$SNAPSHOT_NAME" ${BACKUP_DIR}
fi

# rotate old backups
echo "Rotating backups..."
export OLD_BACKUPS="$(find ${BACKUP_DIR}/* -mtime "+$RETENTION")"
export RECENT_BACKUP_COUNT="$(find ${BACKUP_DIR}/* -mtime "-$RETENTION" | wc -l)"
if [ "$OLD_BACKUPS" ] && [ "$RECENT_BACKUP_COUNT" -ge "$RETENTION" ];
    then echo "Deleting backups older than "$RETENTION" days:";
    echo "$OLD_BACKUPS";
    rm -v $OLD_BACKUPS;
fi
export CURRENT_BACKUPS="$(find ${BACKUP_DIR}/*)"
if [ "$CURRENT_BACKUPS" ]; then echo "Current backups:"; echo "$CURRENT_BACKUPS"; fi
