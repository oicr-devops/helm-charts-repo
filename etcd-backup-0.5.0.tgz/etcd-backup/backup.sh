#!/bin/sh
set -e
# etcd credentials
. /etc/etcd.env
export TIMESTAMP=$(date +%Y-%m-%d-%H-%M-%S)
export SNAPSHOT_NAME="/backup/etcd-snapshot-${TIMESTAMP}.db"
export BACKUP_DIR="/backup-target/etcd"

if [ ! -d $BACKUP_DIR ]; then
  mkdir $BACKUP_DIR
fi

# dump etcd database
echo "Exporting etcd database..."
etcdctl --cacert="$ETCD_PEER_TRUSTED_CA_FILE" --cert="$ETCD_CERT_FILE" --key="$ETCD_KEY_FILE" snapshot save "$SNAPSHOT_NAME"
gzip "$SNAPSHOT_NAME"
export SNAPSHOT_NAME=$SNAPSHOT_NAME.gz

if [ $ENCRYPTION_ENABLED = "true" ];then
  echo "Encrypting backups..."
  openssl aes-256-cbc -v -a -salt -in "$SNAPSHOT_NAME"  -out "$SNAPSHOT_NAME.enc" -pbkdf2 -kfile /etc/etcd-backup-key/password
  export SNAPSHOT_NAME=$SNAPSHOT_NAME.enc
fi

echo "Copying backups to the target..."
chown -R backup-infra "$SNAPSHOT_NAME"
su backup-infra -s /bin/sh -c 'cp "$SNAPSHOT_NAME" ${BACKUP_DIR}'
rm -f /backup/etcd-snapshot*

# rotate old backups
echo "Rotating backups..."
export OLD_BACKUPS="$(find ${BACKUP_DIR}/* -mtime "+$RETENTION")"
export RECENT_BACKUP_COUNT="$(find ${BACKUP_DIR}/* -mtime "-$RETENTION" | wc -l)"
su backup-infra -s /bin/sh -c  \
  'if [ "$OLD_BACKUPS" ] && [ "$RECENT_BACKUP_COUNT" -ge "$RETENTION" ];
    then echo "Deleting backups older than "$RETENTION" days:";
    echo "$OLD_BACKUPS";
    rm -v $OLD_BACKUPS;
  fi'
export CURRENT_BACKUPS="$(find ${BACKUP_DIR}/*)"
if [ "$CURRENT_BACKUPS" ]; then echo "Current backups:"; echo "$CURRENT_BACKUPS"; fi
