#!/bin/sh
set -e

# sets up backup name
export TIMESTAMP=$(date +%Y-%m-%d-%H-%M-%S)
export TMP_DIR="/backup"
export BACKUP_DIR="/backup-target/${BACKUP_ID}"
export SNAPSHOT_NAME="${TMP_DIR}/${BACKUP_ID}/${BACKUP_ID}-snapshot-${TIMESTAMP}"
export VAULT=$(which vault)
export JQ=$(which jq)

if [ ! -d "$BACKUP_DIR" ]; then
  mkdir $BACKUP_DIR
fi

if [ "$VAULT_CONNECT" = "true" ];then
  # logs into vault
  export SA_TOKEN=$(cat /var/run/secrets/kubernetes.io/serviceaccount/token) \
  && export VAULT_TOKEN=$($VAULT write -field=token auth/kubernetes/login role=${VAULT_K8_ROLE} jwt=${SA_TOKEN})
  export MONGO_USERNAME=$( $VAULT kv get -field=DB_USERNAME ${VAULT_SECRET_PATH})
  export MONGO_PASSWORD=$( $VAULT kv get -field=DB_PASSWORD ${VAULT_SECRET_PATH})
fi

# creates mongo dump
echo "Creating mongo dump...."
mongodump --username=${MONGO_USERNAME} --host=${MONGO_HOST} --port=${MONGO_PORT} \
  --authenticationDatabase=${MONGO_AUTH_DATABASE} --db=${MONGO_DATABASE} --out=$SNAPSHOT_NAME --password=${MONGO_PASSWORD} \
  && tar -cv $SNAPSHOT_NAME | gzip > "${SNAPSHOT_NAME}.tar.gz" \
  && rm -rf $SNAPSHOT_NAME

export SNAPSHOT_NAME=$SNAPSHOT_NAME.tar.gz

# moves mongo dump to backup backup volume
if [ "$ENCRYPTION_ENABLED" = "true" ];then
  echo "Encrypting...."

  echo "Encrypting mongo dump...."
  openssl aes-256-cbc -v -a -salt -in "${SNAPSHOT_NAME}.tar.gz"  -out "${SNAPSHOT_NAME}.enc" -kfile "/etc/encrypt-key/password"
  export SNAPSHOT_NAME=$SNAPSHOT_NAME.enc
fi
echo "Copying backups to the target..."
cp "${SNAPSHOT_NAME}" /backup-target/${BACKUP_ID}
export OLD_BACKUPS="$(find ${BACKUP_DIR}/* -mtime "+$RETENTION")"
export RECENT_BACKUP_COUNT="$(find ${BACKUP_DIR}/* -mtime "-${RETENTION}" | wc -l)"
if [ "$OLD_BACKUPS" ] && [ "$RECENT_BACKUP_COUNT" -ge "$RETENTION" ];
  then echo "Deleting backups older than "$RETENTION" days:";
  echo "$OLD_BACKUPS";
  rm -v $OLD_BACKUPS;
fi
export CURRENT_BACKUPS="$(find ${BACKUP_DIR}/*)"
if [ "$CURRENT_BACKUPS" ]; then echo "Current backups:"; echo "$CURRENT_BACKUPS"; fi
