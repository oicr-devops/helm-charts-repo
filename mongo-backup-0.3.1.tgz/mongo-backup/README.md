## mongo-backup

Backup mongo data to a persistent volume claim. It is NFS for now and create manually.
Mongo client creates snapshot and saves locally as encrypted file.

## Install the chart

- if connecting to vault to get secrets in the backup pod, set the following values

      vaultConnect: true

      backupConfigs:
        VAULT_ADDR: https://vault.local
        VAULT_K8_ROLE: mongo-role
        VAULT_SECRET_PATH: kv/secret/mongo


- get the credentials from existing secret

      kubeSecret: true
      secretKeyRef:
        name: my-secret
        key: mongodb-user-password

- to sync the kubernetes native secret with Vault using vault secrets operator

      VaultStaticSecret:
        create: true

      VaultStaticSecrets:
        - name: my-static-secret
          destination:
            create: true
            name: "my-secret"
          mount: "mount-name"
          path: "secret-path"
          refreshAfter: 31s
          type: kv-v2
          vaultAuthRef: vso
      VaultAuth:
        create: true
        name: vso
        spec:
          kubernetes:
            audiences:
            - my-audience
            role: my-role
            serviceAccount: my-service-account
          method: kubernetes
          mount: kubernetes
          namespace: my-namespace

- install the chart:

      helm upgrade -i dac-mongo-backup dac-mongo-backup

## Values

Mongo client use Vault to authenticate.

Job schedule (cron)

- `schedule: "55 */6 * * *"`

Volume claim name

- `targetPvcName: nfs-1`

Service account:

- `serviceAccount.name`: register this with vault policy

backupConfigs:

- `backupConfigs.MONGO_HOST`: FDQN of mongo to back up
- `backupConfigs.MONGO_PORT`: port number
- `backupConfigs.MONGO_DATABASE`: `dac` by default
- `backupConfigs.MONGO_REPLICASET`: `rs0` by default
- `backupConfigs.BACKUP_ID`: this goes into `backup_target/<- backupConfigs.BACKUP_ID>` in the nfs
- `backupConfigs.VAULT_SECRET_PATH`: path to mongo secret in vault
- `backupConfigs.VAULT_K8_ROLE`: register this with vault for pod role
- `backupConfigs.VAULT_ADDR`: FDQN of vault to retrieve secret from
