
#!/bin/sh
set -e

# sets up backup name
export TIMESTAMP=$(date +%Y-%m-%d-%H-%M-%S)
export TMP_DIR="/backup"
export SNAPSHOT_NAME="${TMP_DIR}/${BACKUP_ID}-snapshot-${TIMESTAMP}"
export BACKUP_DIR="/backup-target/${BACKUP_ID}"

if [ ! -d $BACKUP_DIR ]; then
  mkdir $BACKUP_DIR
fi

# Dump Database from postgresql
echo "Connecting to postgres database...."
pg_dump --verbose --format=tar -f "${SNAPSHOT_NAME}.tar"
echo "Exit code: $?"
test -e "${SNAPSHOT_NAME}.tar"
echo "Created archive: ${SNAPSHOT_NAME}.tar"
gzip "${SNAPSHOT_NAME}.tar"
export SNAPSHOT_NAME=$SNAPSHOT_NAME.tar.gz

if [ $ENCRYPTION_ENABLED = "true" ];then
  echo "Encrypting...."
  openssl aes-256-cbc -v -a -salt -in "${SNAPSHOT_NAME}" -out "${SNAPSHOT_NAME}.enc" -pbkdf2 -kfile "/etc/backup-key/password"
  export SNAPSHOT_NAME=$SNAPSHOT_NAME.enc
fi
echo "Copying backups to the target..."
cp "${SNAPSHOT_NAME}" /backup-target/${BACKUP_ID}
export OLD_BACKUPS="$(find ${BACKUP_DIR}/* -mtime "+$RETENTION")"
export RECENT_BACKUP_COUNT="$(find ${BACKUP_DIR}/* -mtime "-${RETENTION}" | wc -l)"
if [ "$OLD_BACKUPS" ] && [ "$RECENT_BACKUP_COUNT" -ge "$RETENTION" ];
  then echo "Deleting backups older than "$RETENTION" days:";
  echo "$OLD_BACKUPS";
  rm -v $OLD_BACKUPS;
fi
export CURRENT_BACKUPS="$(find ${BACKUP_DIR}/*)"
if [ "$CURRENT_BACKUPS" ]; then echo "Current backups:"; echo "$CURRENT_BACKUPS"; fi
